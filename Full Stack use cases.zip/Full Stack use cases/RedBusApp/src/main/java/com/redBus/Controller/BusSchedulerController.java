package com.redBus.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusSchedulerDTO;
import com.redBus.service.BusSchedulerService;

@RestController
@RequestMapping("/bus-schedulers")
@CrossOrigin(origins = "*")
public class BusSchedulerController {
    @Autowired
    private BusSchedulerService busSchedulerService;

    @PostMapping("/postScedule")
    public ResponseEntity<BusScheduler> saveBusScheduler(@RequestBody BusSchedulerDTO busSchedulerDto) {
        BusScheduler busScheduler = busSchedulerService.saveBusScheduler(busSchedulerDto);
        return new ResponseEntity<>(busScheduler, HttpStatus.CREATED);
    }

    @GetMapping("/getAllSchedule")
    public ResponseEntity<List<BusScheduler>> getAllBusSchedulers() {
        List<BusScheduler> busSchedulers = busSchedulerService.getAllBusSchedulers();
        return new ResponseEntity<>(busSchedulers, HttpStatus.OK);
    }
    
    @GetMapping("/{source}/{destination}")
    public ResponseEntity<?> getBusBySourceDestinationAndDate(@PathVariable String source, @PathVariable String destination) {
       List<?> busSchedulerDTO = busSchedulerService.getBusBySourceDestinationAndDate(source, destination);
        if (busSchedulerDTO != null) {
            return ResponseEntity.ok(busSchedulerDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
