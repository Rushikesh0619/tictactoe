package com.redBus.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.model.Bus;
import com.redBus.model.Seats;
import com.redBus.model.dto.SeatsDTO;
import com.redBus.repository.BusRepository;
import com.redBus.repository.SeatsRepository;
import com.redBus.service.SeatsService;

@Service
public class SeatsServiceImpl implements SeatsService {
	@Autowired
	private SeatsRepository seatRepository;

	@Autowired
	private BusRepository busRepository;

	@Override
	public List<Seats> postSeats(List<SeatsDTO> seatDTOList) {
		List<Seats> seatsList = new ArrayList<>();
		for (SeatsDTO seatDTO : seatDTOList) {
			Seats seat = new Seats();
			seat.setSeatName(seatDTO.getSeatName());
			seat.setSeatType(seatDTO.getSeatType());
			seat.setSeatStatus(seatDTO.isSeatStatus());
			seat.setSeatPrice(seatDTO.getSeatPrice());
			Bus bus = busRepository.findById(seatDTO.getBusId())
					.orElseThrow(() -> new BusNotFoundException("Bus not found with id: " + seatDTO.getBusId()));
			seat.setBus(bus);
			seatsList.add(seat);
		}
		return seatRepository.saveAll(seatsList);
	}

}
