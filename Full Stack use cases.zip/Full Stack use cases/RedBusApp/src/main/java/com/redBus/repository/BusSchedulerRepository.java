package com.redBus.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.redBus.model.BusScheduler;
@Repository
public interface BusSchedulerRepository extends JpaRepository<BusScheduler, Long>{
	List<BusScheduler> findBySourceAndDestination(String source, String destination);
}
