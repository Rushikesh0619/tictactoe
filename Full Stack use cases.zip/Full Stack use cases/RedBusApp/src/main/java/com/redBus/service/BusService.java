package com.redBus.service;

import java.util.List;

import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusDTO;

public interface BusService {
	Bus saveBus(BusDTO busDto);
	List<Bus> getAllBuses();
	List<BusScheduler> getBusSchedulers(Long busId);
	List<Bus> getBusesBetween(String source, String destination);
}
