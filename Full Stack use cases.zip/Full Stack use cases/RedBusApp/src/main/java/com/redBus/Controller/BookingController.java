package com.redBus.Controller;

import org.springframework.http.MediaType;

import java.security.GeneralSecurityException;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.redBus.model.dto.BookingRequest;
import com.redBus.model.dto.BookingResponse;
import com.redBus.service.BookingService;

@RestController
@RequestMapping(value="/bookings")
public class BookingController {
	@Autowired
	private BookingService bookingService;

   


	
	@PostMapping(value="/book")//,consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookingResponse> createBooking(@RequestBody BookingRequest bookingRequest)throws GeneralSecurityException, ParseException {
        

        BookingResponse bookingResponse = bookingService.createBooking(bookingRequest.getUserId(), bookingRequest.getBusSchedulerId(),bookingRequest.getNoOfSeats(),bookingRequest.getPassengerList());
        return new ResponseEntity<>(bookingResponse,HttpStatus.ACCEPTED);
    }
}

