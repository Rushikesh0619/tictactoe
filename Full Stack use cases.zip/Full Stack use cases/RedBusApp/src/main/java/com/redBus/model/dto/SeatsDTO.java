package com.redBus.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SeatsDTO {

	private String seatName;
	private String seatType;
	private Double seatPrice;
	private boolean seatStatus;
	private Long busId;
	private Long bookingId;

}
