package com.redBus.FunctionalInterface;

import java.util.List;

import com.redBus.model.BusScheduler;

@FunctionalInterface
public interface TotalPriceCalculator {
	double calculate(BusScheduler busScheduler, List<String> selectedSeats);
}
