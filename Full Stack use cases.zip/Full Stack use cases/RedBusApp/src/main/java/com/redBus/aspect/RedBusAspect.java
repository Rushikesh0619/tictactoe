package com.redBus.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.redBus.model.Users;
import com.redBus.model.dto.BookingResponse;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Slf4j
@Component
public class RedBusAspect {
	@Pointcut("execution(* com.redBus.Controller.UserController.*(..))")
    public void userControllerMethods() {}
	
	@Pointcut("execution(* com.redBus.Controller.BookingController.*(..))")
    public void bookingControllerMethods() {}
	
	@Pointcut("execution(* com.redBus.Controller.BusController.*(..))")
    public void busControllerMethods() {}
	
	@Pointcut("execution(* com.redBus.Controller.BusSchedulerController.*(..))")
    public void busSchedulerControllerMethods() {}
	
	@Pointcut("execution(* com.redBus.Controller.SeatsController.*(..))")
    public void seatsControllerMethods() {}
	
	@AfterThrowing(pointcut = "userControllerMethods()",throwing = "ex")
	public void afterExceptionUser(JoinPoint joinPoint, Exception ex) {
		log.error("User logs "+ ex.getLocalizedMessage());
	}
	
	@AfterThrowing(pointcut = "bookingControllerMethods()",throwing = "ex")
	public void afterExceptionBooking(JoinPoint joinPoint, Exception ex) {
		log.error("Booking Logs: "+ ex.getLocalizedMessage());
	}
	@AfterThrowing(pointcut = "busControllerMethods()",throwing = "ex")
	public void afterExceptionBus(JoinPoint joinPoint, Exception ex) {
		log.error("Bus Logs: "+ ex.getLocalizedMessage());
	}
	@AfterThrowing(pointcut = "busSchedulerControllerMethods()",throwing = "ex")
	public void afterExceptionBusScheduler(JoinPoint joinPoint, Exception ex) {
		log.error("Bus Scheduler Logs: "+ ex.getLocalizedMessage());
	}
	
	@AfterThrowing(pointcut = "seatsControllerMethods()",throwing = "ex")
	public void afterExceptionSeats(JoinPoint joinPoint, Exception ex) {
		log.error("Seats Logs: "+ ex.getLocalizedMessage());
	}
	@AfterReturning(pointcut = "bookingControllerMethods()", returning = "result")
    public void afterReturningCreateBooking(JoinPoint joinPoint, ResponseEntity<BookingResponse> result) {
        if (result.getStatusCode().is2xxSuccessful()) {
            log.info("Booking created successfully. Response: {}", result.getBody());
        } else {
            log.warn("Booking creation failed. HTTP Status: {}", result.getStatusCode());
        }
    }
	
	@AfterReturning(pointcut = "userControllerMethods()", returning = "result")
	public void afterReturningLogin(JoinPoint joinPoint, ResponseEntity<Users> result) {
	    if (result.getStatusCode().is2xxSuccessful()) {
	        log.info("Login successful. User: {}", result.getBody());
	    }   
	}


}
