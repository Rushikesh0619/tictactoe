package com.redBus.service.serviceimpl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.Exceptions.UserNotFoundException;
import com.redBus.model.Bookings;
import com.redBus.model.BusScheduler;
import com.redBus.model.Passenger;
import com.redBus.model.Users;
import com.redBus.model.dto.BookingResponse;
import com.redBus.repository.BookingRepository;
import com.redBus.repository.BusSchedulerRepository;
import com.redBus.repository.UserRepository;
import com.redBus.service.BookingService;
@Service
public class BookingServiceImpl implements BookingService{
    @Autowired
	BookingRepository bookingRepository;
	
	@Autowired
	private BusSchedulerRepository busSchedulerRepository;
    
    @Autowired
    private UserRepository userRepository;
	


    
    public BookingResponse createBooking(Long userId, Long busSchedulerId, int noOfSeats,List<Passenger>passengerList) {
        // Get the user details
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        // Get the bus scheduler details
        BusScheduler busScheduler = busSchedulerRepository.findById(busSchedulerId)
                .orElseThrow(() -> new BusNotFoundException("Bus not found with id: " + busSchedulerId));

        // Calculate remaining number of seats
        int newCapacity = busScheduler.getBus().getCapacity() - noOfSeats;
        busScheduler.getBus().setCapacity(newCapacity);

        // Create a new booking
        Bookings booking = new Bookings();
        booking.setUser(user);
        booking.setBusScheduler(busScheduler);
        booking.setBookingDate(new Date());
        booking.setNumberOfSeats(noOfSeats);
        booking.setPassengers(passengerList);
        // Save the booking
        bookingRepository.save(booking);

        // Print the booking details
        System.out.println("Booking Details:");
        System.out.println("Booking ID: " + booking.getBookingId());
        System.out.println("Booking Date: " + booking.getBookingDate());
        System.out.println("Number of Seats: " + booking.getNumberOfSeats());

        // Print the bus scheduler details
        System.out.println("Bus Scheduler Details:");
        System.out.println("Bus Scheduler ID: " + busScheduler.getBusSchedulerId());
        System.out.println("Date: " + busScheduler.getDate());
        System.out.println("Source: " + busScheduler.getSource());
        System.out.println("Destination: " + busScheduler.getDestination());

        // Bus Details
        System.out.println("Bus Details");
        System.out.println("Bus Number: " + busScheduler.getBus().getBusNumber());
        System.out.println("Operator: " + busScheduler.getBus().getOperator());

        // Print the user details
        System.out.println("User Details:");
        System.out.println("User ID: " + user.getId());
        System.out.println("Name: " + user.getName());
        System.out.println("Email: " + user.getEmail());
        System.out.println("Username: " + user.getUsername());
        
//        System.out.println("Passenger Details:");
//        for (Passenger passenger : booking.getPassengers()) {
//            System.out.println("Passenger Name: " + passenger.getNameOfPassenger());
//            System.out.println("Passenger age: "+passenger.getAge());
//            // Display other passenger details as needed
//        }

        // Build and return the booking response
        BookingResponse bookingResponse = new BookingResponse();
        bookingResponse.setBook_id(booking.getBookingId());
        bookingResponse.setDate1(booking.getBookingDate());
        bookingResponse.setNumberOfSeats(booking.getNumberOfSeats());
        bookingResponse.setBusSceduler_id(busScheduler.getBusSchedulerId());
        bookingResponse.setDate2(busScheduler.getDate());
        bookingResponse.setSourceCity(busScheduler.getSource());
        bookingResponse.setDestinationCity(busScheduler.getDestination());
        bookingResponse.setBusNumber(busScheduler.getBus().getBusNumber());
        bookingResponse.setBusOperator(busScheduler.getBus().getOperator());
        bookingResponse.setUserName(user.getName());
        bookingResponse.setUserEmail(user.getEmail());
        bookingResponse.setListOfPassenger(passengerList);

        return bookingResponse;
    }

}
