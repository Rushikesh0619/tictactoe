package com.redBus.Exceptions;

public class InvalidCredentialsException extends RuntimeException{
public InvalidCredentialsException() {
	super();
}
}
