package com.redBus.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redBus.Exceptions.InvalidCredentialsException;
import com.redBus.Exceptions.UserAlreadyExistsException;
import com.redBus.Exceptions.UserNotFoundException;
import com.redBus.model.Bookings;
import com.redBus.model.Bus;
import com.redBus.model.Users;
import com.redBus.model.dto.UserDto;
import com.redBus.repository.UserRepository;
import com.redBus.service.UserService;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
	private UserRepository userRepository;
    

    public Users findUser(String email) {
    	Users existingUser = userRepository.findByEmail(email);
    	if(existingUser == null) {
    		throw new UserNotFoundException("User Not Found");
    	}
    	else {
    		return existingUser;
    	}
    }
	@Override
	public Users registerUser(UserDto userDto) {
		Users existingUserWithEmail = userRepository.findByEmail(userDto.getEmail());
	    if (existingUserWithEmail != null) {
	        throw new UserAlreadyExistsException("User with email " + userDto.getEmail() + " already exists");
	    }
	    Users existingUserWithUserName = userRepository.findByUsername(userDto.getUsername());
	    if (existingUserWithUserName != null) {
	        throw new UserAlreadyExistsException("User with userName " + userDto.getUsername() + " already exists");
	    }
		Users user= new Users();
		user.setName(userDto.getName());
		user.setUsername(userDto.getUsername());
		user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setRole(userDto.getRole());
        return userRepository.save(user);		
	}
	public List<Users> getAllUsers() {
        List<Users> userss = userRepository.findAll();
        return userss;
    }
	public Users login(UserDto userDto) {
	    Users user = userRepository.findByUsername(userDto.getUsername());
	    if (user == null || !user.getPassword().equals(userDto.getPassword())) {
	    	throw new InvalidCredentialsException();
	    }
	    return user;
	}
	
	public Users updateUser(String email, UserDto user) {
		Users existingUser = userRepository.findByEmail(email);
		if(existingUser == null) {
    		throw new UserNotFoundException("User Not Found");
    	}
    	else {
    		existingUser.setEmail(user.getEmail());
    		existingUser.setName(user.getName());
    		existingUser.setUsername(user.getUsername());
    		
    		return existingUser;
    	}
		
	}
	@Override
	public List<Bookings> getAllBookings(Long userid) {
		Users user = userRepository.findById(userid).orElse(null);
        if (user == null) {
            return null;
        }
        return user.getBookings();
	}


	
	

	
    
    
}
