package com.redBus.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.redBus.model.dto.UserDto;
import com.redBus.model.*;
import com.redBus.service.serviceimpl.UserServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {
    @Autowired
	UserServiceImpl userService;
    
    @PostMapping("/register")
    public ResponseEntity<Users> register(@RequestBody @Valid UserDto userDto) {
        return new ResponseEntity<Users>(userService.registerUser(userDto),HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<Users>  login(@RequestBody  UserDto userDto) {
       return new ResponseEntity<Users>(userService.login(userDto),HttpStatus.ACCEPTED);
    }
    
    @GetMapping("/users")
    public ResponseEntity<List<Users>> getAll() {
        List<Users> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }
    
    @GetMapping("/users/{email}")
    public ResponseEntity<Users> getByEmail(@PathVariable String email){
          return new ResponseEntity<Users>(userService.findUser(email),HttpStatus.OK);
    }
    @PutMapping("/update/{email}")
    public ResponseEntity<Users> updateUser(@PathVariable String email, @RequestBody UserDto user){
    	return new ResponseEntity<Users>(userService.updateUser(email, user),HttpStatus.OK);
    }
    
    @GetMapping("/getAllBookings/{userid}")
    public ResponseEntity<List<Bookings>> getAllBookings(@PathVariable Long userid){
    	return new ResponseEntity<List<Bookings>>(userService.getAllBookings(userid),HttpStatus.OK);
    }
}
