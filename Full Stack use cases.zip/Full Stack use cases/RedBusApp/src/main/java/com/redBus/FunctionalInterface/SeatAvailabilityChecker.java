package com.redBus.FunctionalInterface;

import java.util.List;

import com.redBus.model.BusScheduler;

@FunctionalInterface
public interface SeatAvailabilityChecker {
	boolean checkAndUpdate(BusScheduler busScheduler, List<String> selectedSeats);
}
