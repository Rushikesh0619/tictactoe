package com.redBus.Exceptions;

public class BusNotFoundException extends RuntimeException {
public BusNotFoundException(String message) {
	// TODO Auto-generated constructor stub
	super(message);
}
}
