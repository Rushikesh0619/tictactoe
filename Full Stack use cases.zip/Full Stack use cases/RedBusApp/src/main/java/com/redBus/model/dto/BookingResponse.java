package com.redBus.model.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.redBus.model.Passenger;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingResponse {
	private Long book_id;
	private Date date1;
	private int numberOfSeats;
	//
	
	private Long busSceduler_id;
	private Date date2;
	private String sourceCity;
	private String destinationCity;
	//
	
	private String busNumber;
	private String busOperator;
	private String UserName;
	private String UserEmail;
	
   private List<Passenger> listOfPassenger = new ArrayList<>();
}
