package com.redBus.model.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserHistory {

	private long bookingId;
	private Date bookingDate;
	private int noOfSeats;
	private String source;
	private String destination;
	private Date dateOfTravel;
}
