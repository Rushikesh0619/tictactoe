package com.redBus.model.dto;

import lombok.Data;

@Data
public class UserBookings {

	
}
