package com.redBus.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusDTO;
import com.redBus.repository.BusRepository;
import com.redBus.repository.BusSchedulerRepository;
import com.redBus.service.BusService;
@Service
public class BusServiceImpl implements BusService{
    @Autowired
    private BusRepository busRepository;
    
    @Autowired
	private BusSchedulerRepository busSchedulerRepository;
    
	@Override
	public Bus saveBus(BusDTO busDto) {
		Bus bus = new Bus();
        bus.setBusNumber(busDto.getBusNumber());
        bus.setOperator(busDto.getOperator());
        bus.setCapacity(busDto.getCapacity());
        return busRepository.save(bus);
	}

	@Override
	public List<Bus> getAllBuses() {
		 return busRepository.findAll();
	}

	@Override
	public List<BusScheduler> getBusSchedulers(Long busId) {
		Bus bus = busRepository.findById(busId).orElse(null);
        if (bus == null) {
            return null;
        }
        return bus.getBusSchedulers();
	}
	public List<Bus> getBusesBetween(String source, String destination) {
	    List<Bus> buses = new ArrayList<>();
	    List<BusScheduler> busSchedulers = busSchedulerRepository.findBySourceAndDestination(source, destination);
	    for (BusScheduler busScheduler : busSchedulers) {
	        buses.add(busScheduler.getBus());
	    }
	    if(buses.isEmpty()) {
	    	throw new BusNotFoundException("No bus found");
	    	
	    }else {
	    return buses;
	    }
	}


}
