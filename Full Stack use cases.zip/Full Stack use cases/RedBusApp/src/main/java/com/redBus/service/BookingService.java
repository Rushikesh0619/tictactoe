package com.redBus.service;

import java.util.List;

import com.redBus.model.Passenger;
import com.redBus.model.dto.BookingResponse;

public interface BookingService {
	//BookingDTO bookBus(Long busSchedulerId, Long userId, int numberOfSeats);
	BookingResponse createBooking(Long userId, Long busSchedulerId,int noOfSeats,List<Passenger>passengerList);
}
