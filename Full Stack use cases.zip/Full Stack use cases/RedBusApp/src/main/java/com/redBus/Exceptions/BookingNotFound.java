package com.redBus.Exceptions;

public class BookingNotFound extends RuntimeException{
public BookingNotFound(String message) {
	// TODO Auto-generated constructor stub
	super(message);
}
}
