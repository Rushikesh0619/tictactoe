package com.redBus.model.dto;

import org.hibernate.validator.constraints.UniqueElements;

import com.redBus.model.Users;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
	
	@NotNull(message = "Enter valid name")
    private String name;
	
	@Email(message = "Enter valid email")
    private String email;
	
	@NotNull(message = "UserName cannot be null")
    private String username;
    
	@NotNull(message = "Password cannot be null")
    private String password;
	
	
    private String role =  "USER";
	
}
