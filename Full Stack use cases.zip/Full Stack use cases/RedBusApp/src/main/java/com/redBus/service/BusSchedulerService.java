package com.redBus.service;

import java.time.LocalDate;
import java.util.List;

import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusSchedulerDTO;

public interface BusSchedulerService {
	BusScheduler saveBusScheduler(BusSchedulerDTO busSchedulerDTO);
	List<BusScheduler> getAllBusSchedulers();
	List<?> getBusBySourceDestinationAndDate(String source, String destination);
	//List<Bus> getAllBuses();
}
