package com.redBus.service;

import java.util.List;

import com.redBus.model.Seats;
import com.redBus.model.dto.SeatsDTO;

public interface SeatsService {
	List<Seats> postSeats(List<SeatsDTO> seatDTO);
}
