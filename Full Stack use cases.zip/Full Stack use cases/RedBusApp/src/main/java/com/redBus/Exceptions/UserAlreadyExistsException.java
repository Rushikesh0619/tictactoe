package com.redBus.Exceptions;

public class UserAlreadyExistsException extends RuntimeException {
 public UserAlreadyExistsException(String message) {
	// TODO Auto-generated constructor stub
	 super(message);
}
}
