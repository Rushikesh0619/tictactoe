package com.redBus.model.dto;

import java.sql.Date;

import com.redBus.model.Bus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BusSchedulerDTO {
	private long bsId;
	private Date date;
    private String source;
    private String destination;
    private Long busId;
    private BusDTO busDto;
    
   
    	
    
}
