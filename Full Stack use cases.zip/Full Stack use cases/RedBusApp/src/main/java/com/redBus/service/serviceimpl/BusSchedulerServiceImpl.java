package com.redBus.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusDTO;
import com.redBus.model.dto.BusSchedulerDTO;
import com.redBus.repository.BusRepository;
import com.redBus.repository.BusSchedulerRepository;
import com.redBus.service.BusSchedulerService;
@Service
public class BusSchedulerServiceImpl implements BusSchedulerService {
    @Autowired
	private BusSchedulerRepository busSchedulerRepository;
    
    @Autowired
    private BusRepository busRepository;
    
	@Override
	public BusScheduler saveBusScheduler(BusSchedulerDTO busSchedulerDTO) {
	    BusScheduler busScheduler = new BusScheduler();
	    busScheduler.setDate(busSchedulerDTO.getDate());
	    busScheduler.setSource(busSchedulerDTO.getSource());
	    busScheduler.setDestination(busSchedulerDTO.getDestination());

	    // Fetch the existing Bus entity or create a new one
	    Bus bus = busRepository.findById(busSchedulerDTO.getBusId()).orElse(null);

	    if (bus == null) {
	        bus = new Bus();
	        bus.setBus_id(busSchedulerDTO.getBusId());
	        busRepository.save(bus);
	    }

	    busScheduler.setBus(bus);

	    return busSchedulerRepository.save(busScheduler);
	}



	


	    

	public List<BusSchedulerDTO> getBusBySourceDestinationAndDate(String source, String destination) {
	    List<BusSchedulerDTO> list = new ArrayList<>();
	    List<BusScheduler> busSchedulers = busSchedulerRepository.findAll();

	    for (BusScheduler busScheduler : busSchedulers) {
	        if (busScheduler.getSource().equals(source) && busScheduler.getDestination().equals(destination)) {
	            Bus bus = busScheduler.getBus();
	            BusDTO busDto = new BusDTO();
	            busDto.setBusNumber(bus.getBusNumber());
	            busDto.setCapacity(bus.getCapacity());
	            busDto.setOperator(bus.getOperator());
	            list.add(new BusSchedulerDTO(busScheduler.getBusSchedulerId(),busScheduler.getDate(), busScheduler.getSource(), busScheduler.getDestination(), bus.getBus_id(),busDto));
	        }
	    }
	    if(list.isEmpty()) {
	    	throw new BusNotFoundException("Bus not found");
	    }else {
	    return list;
	    }
	}






	@Override
	public List<BusScheduler> getAllBusSchedulers() {
		List<BusScheduler> busSchedulers = busSchedulerRepository.findAll();
	    for (BusScheduler busScheduler : busSchedulers) {
	        busScheduler.setBus(busRepository.findById(busScheduler.getBus().getBus_id()).orElse(null));
	    }
	    return busSchedulers;
	}








	

	}



