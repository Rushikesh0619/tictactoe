package com.redBus.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusDTO;
import com.redBus.service.BusService;
import com.redBus.service.serviceimpl.BusServiceImpl;

@RestController
@RequestMapping("/buses")
public class BusController {
    @Autowired
    private BusServiceImpl busService;

    @PostMapping("/postBus")
    public ResponseEntity<Bus> saveBus(@RequestBody BusDTO busDto) {
        Bus bus = busService.saveBus(busDto);
        return new ResponseEntity<>(bus, HttpStatus.CREATED);
    }

    @GetMapping("/getAllBus")
    public ResponseEntity<List<Bus>> getAllBuses() {
        List<Bus> buses = busService.getAllBuses();
        return new ResponseEntity<>(buses, HttpStatus.OK);
    }

    @GetMapping("/{busId}/schedulers")
    public ResponseEntity<List<BusScheduler>> getBusSchedulers(@PathVariable Long busId) {
        List<BusScheduler> busSchedulers = busService.getBusSchedulers(busId);
        if (busSchedulers == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(busSchedulers, HttpStatus.OK);
    }
    @GetMapping("/{source}/{destination}")
    public List<Bus> getBusesBetween(@PathVariable String source, @PathVariable String destination) {
        return busService.getBusesBetween(source, destination);
    }
}
