package com.redBus.service;

import java.util.List;

import com.redBus.model.Bookings;
import com.redBus.model.Users;
import com.redBus.model.dto.UserDto;

public interface UserService {
	Users findUser(String email);
	Users registerUser (UserDto userDto);
	List<Users> getAllUsers();
	Users login(UserDto userDto);
	List<Bookings> getAllBookings(Long userid);
}
