package com.redBus.ExceptionHandler;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.Exceptions.InvalidCredentialsException;
import com.redBus.Exceptions.UserAlreadyExistsException;
import com.redBus.Exceptions.UserNotFoundException;

import jakarta.persistence.UniqueConstraint;
@RestControllerAdvice
public class ExceptionHandlerRedBus {
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(InvalidCredentialsException.class)
	public ResponseEntity<String> exceptionHandler(InvalidCredentialsException ex) {
	     return new ResponseEntity<>("Invalid login cerdentails",HttpStatus.UNAUTHORIZED);
}
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public String handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        String errorMessage = ex.getBindingResult().getFieldError().getDefaultMessage();
        return errorMessage;
    }
    @ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(UserAlreadyExistsException.class)
	public ResponseEntity<String> existingUser(UserAlreadyExistsException ex) {
	     return new ResponseEntity<>(ex.getLocalizedMessage(),HttpStatus.BAD_REQUEST);
}
    @ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(BusNotFoundException.class)
	public ResponseEntity<String> noBusFound(BusNotFoundException bs) {
	     return new ResponseEntity<>(bs.getLocalizedMessage(),HttpStatus.BAD_REQUEST);
    }
    
    @ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<String> noBusFound(UserNotFoundException us) {
	     return new ResponseEntity<>(us.getLocalizedMessage(),HttpStatus.BAD_REQUEST);
    }
    
}
