package com.redBus.model.dto;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.redBus.model.Passenger;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor

public class BookingRequest {
    private Long userId;
    private Long busSchedulerId;
    private int noOfSeats;
    private List<Passenger> passengerList;
}
