package com.redBus.model.dto;

import java.sql.Date;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingDTO {
	private String userName;
    private String source;
    private String destination;
    private Date date;
    private String busNumber;
    private String operator;
    private int numberOfSeats;
    
}
