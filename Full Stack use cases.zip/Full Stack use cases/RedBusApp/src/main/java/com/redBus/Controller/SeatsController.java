package com.redBus.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.redBus.model.Seats;
import com.redBus.model.dto.SeatsDTO;
import com.redBus.service.serviceimpl.SeatsServiceImpl;

@RestController
@RequestMapping("/seats")
public class SeatsController {
	@Autowired
	private SeatsServiceImpl seatsServiceImpl;

	/***
	 * Saves list of seats
	 * 
	 * @param seatDTOList
	 * @return
	 */
	@PostMapping("/postSeats")
	public ResponseEntity<List<Seats>> saveSeats(@RequestBody List<SeatsDTO> seatDTOList) {
		List<Seats> seatList = seatsServiceImpl.postSeats(seatDTOList);
		return new ResponseEntity<>(seatList, HttpStatus.OK);
	}

}
