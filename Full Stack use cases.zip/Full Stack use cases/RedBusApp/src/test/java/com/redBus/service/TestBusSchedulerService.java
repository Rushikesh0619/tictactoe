package com.redBus.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.dto.BusSchdulerdto;
import com.redBus.model.dto.BusSchedulerDTO;
import com.redBus.repository.BusRepository;
import com.redBus.repository.BusSchedulerRepository;
import com.redBus.service.serviceimpl.BusSchedulerServiceImpl;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class TestBusSchedulerService {

    @Mock
    private BusSchedulerRepository busSchedulerRepository;

    @Mock
    private BusRepository busRepository;

    @InjectMocks
    private BusSchedulerServiceImpl busSchedulerService;

    @Test
    public void testSaveBusScheduler() {
        // Create BusSchedulerDTO with hardcoded data
        BusSchdulerdto busSchedulerDto = new BusSchdulerdto();
        busSchedulerDto.setDate(java.sql.Date.valueOf(LocalDate.now()));
        busSchedulerDto.setSource("Source");
        busSchedulerDto.setDestination("Destination");
        busSchedulerDto.setBusId(2L);

        // Perform the test
        BusScheduler savedScheduler = busSchedulerService.saveBusScheduler(busSchedulerDto);

        // Assertions
        Assertions.assertNotNull(savedScheduler);
        Assertions.assertEquals(busSchedulerDto.getDate(), savedScheduler.getDate());
        Assertions.assertEquals(busSchedulerDto.getSource(), savedScheduler.getSource());
        Assertions.assertEquals(busSchedulerDto.getDestination(), savedScheduler.getDestination());
    }

    @Test
    public void testGetBusBySourceDestinationAndDate() {
        // Mock data
        String source = "Bengaluru";
        String destination = "Solapur";
        LocalDate date = LocalDate.of(2023, 12, 20);

        BusScheduler mockedBusScheduler = new BusScheduler();
        mockedBusScheduler.setBus(new Bus());
        mockedBusScheduler.setDate(java.sql.Date.valueOf(date));
        mockedBusScheduler.setSource(source);
        mockedBusScheduler.setDestination(destination);

        // Mock behavior
        Mockito.when(busSchedulerRepository.findBySourceAndDestinationAndDate(source, destination, date))
               .thenReturn(Arrays.asList(mockedBusScheduler));

        // Perform the test
        List<BusSchedulerDTO> busSchedulers = busSchedulerService.getBusBySourceDestinationAndDate(source, destination, date);

        // Assertions
        Assertions.assertNotNull(busSchedulers);
        Assertions.assertFalse(busSchedulers.isEmpty());
        Assertions.assertEquals(1, busSchedulers.size());

        BusSchedulerDTO result = busSchedulers.get(0);

        //Assertions.assertEquals(mockedBusScheduler.getBusSchedulerId(), result.getBusSchedulerId());
        Assertions.assertEquals(mockedBusScheduler.getDate(), result.getDate());
        Assertions.assertEquals(mockedBusScheduler.getSource(), result.getSource());
        Assertions.assertEquals(mockedBusScheduler.getDestination(), result.getDestination());
        Assertions.assertEquals(mockedBusScheduler.getBus().getBus_id(), result.getBusId());
    }


    @Test
    public void testGetAllBusSchedulers() {
        // Mock data
        BusScheduler scheduler = new BusScheduler();
        scheduler.setBus(new Bus());

        // Mock behavior
        Mockito.when(busSchedulerRepository.findAll()).thenReturn(Arrays.asList(scheduler));

        // Perform the test
        List<BusScheduler> busSchedulers = busSchedulerService.getAllBusSchedulers();

        // Assertions
        Assertions.assertNotNull(busSchedulers);
        Assertions.assertFalse(busSchedulers.isEmpty());
    }

    @Test
    public void testGetAllSources() {
        // Mock data
        List<String> sources = Arrays.asList("Source1", "Source2");

        // Mock behavior
        Mockito.when(busSchedulerRepository.findAllDistinctSources()).thenReturn(sources);

        // Perform the test
        List<String> result = busSchedulerService.getAllSources();

        // Assertions
        Assertions.assertNotNull(result);
        Assertions.assertEquals(sources, result);
    }

    @Test
    public void testGetAllDestinations() {
        // Mock data
        List<String> destinations = Arrays.asList("Destination1", "Destination2");

        // Mock behavior
        Mockito.when(busSchedulerRepository.findAllDistinctDestinations()).thenReturn(destinations);

        // Perform the test
        List<String> result = busSchedulerService.getAllDestinations();

        // Assertions
        Assertions.assertNotNull(result);
        Assertions.assertEquals(destinations, result);
    }
}
