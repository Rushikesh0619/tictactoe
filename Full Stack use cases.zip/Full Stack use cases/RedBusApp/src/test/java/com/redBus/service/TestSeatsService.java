package com.redBus.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.model.Bus;
import com.redBus.model.Seats;
import com.redBus.model.dto.SeatsDTO;
import com.redBus.repository.BusRepository;
import com.redBus.repository.SeatsRepository;
import com.redBus.service.SeatsService;
import com.redBus.service.serviceimpl.SeatsServiceImpl;

@SpringBootTest
public class TestSeatsService {

    @Mock
    private SeatsRepository seatsRepository;

    @Mock
    private BusRepository busRepository;

    @InjectMocks
    private SeatsServiceImpl seatsService;

    @Test
    public void testPostSeats() {
        // Mock data
        SeatsDTO seatDTO = new SeatsDTO();
        seatDTO.setSeatName("A1");
        seatDTO.setSeatType("Standard");
        seatDTO.setSeatStatus(true);
        seatDTO.setSeatPrice(50.0);
        seatDTO.setBusId(1L); // Use the existing Bus ID

        // Mock behavior
        Mockito.when(busRepository.findById(Mockito.eq(1L))).thenReturn(java.util.Optional.of(new Bus()));
        Mockito.when(seatsRepository.save(Mockito.any(Seats.class))).thenReturn(new Seats());

        // Perform the test
        Seats savedSeat = seatsService.postSeats(seatDTO);

        // Assertions
        Assertions.assertNotNull(savedSeat);
        Assertions.assertEquals(seatDTO.getSeatName(), savedSeat.getSeatName());
        Assertions.assertEquals(seatDTO.getSeatType(), savedSeat.getSeatType());
        Assertions.assertEquals(seatDTO.isSeatStatus(), savedSeat.isSeatStatus());
        Assertions.assertEquals(seatDTO.getSeatPrice(), savedSeat.getSeatPrice());

        // Clean up: No need to delete as we are using mocks
    }

    @Test
    public void testPostSeatsWithInvalidBusId() {
        // Mock data
        SeatsDTO seatDTO = new SeatsDTO();
        seatDTO.setSeatName("A1");
        seatDTO.setSeatType("Standard");
        seatDTO.setSeatStatus(true);
        seatDTO.setSeatPrice(50.0);
        seatDTO.setBusId(999L); // An invalid bus ID

        // Mock behavior
        Mockito.when(busRepository.findById(Mockito.eq(999L))).thenReturn(java.util.Optional.empty());

        // Perform the test and check for BusNotFoundException
        Assertions.assertThrows(BusNotFoundException.class, () -> {
            seatsService.postSeats(seatDTO);
        });
    }
}
