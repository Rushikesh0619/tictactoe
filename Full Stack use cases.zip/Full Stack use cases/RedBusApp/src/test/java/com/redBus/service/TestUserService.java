package com.redBus.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.redBus.Exceptions.InvalidCredentialsException;
import com.redBus.Exceptions.UserAlreadyExistsException;
import com.redBus.Exceptions.UserNotFoundException;
import com.redBus.model.Bookings;
import com.redBus.model.BusScheduler;
import com.redBus.model.Users;
import com.redBus.model.dto.UserDto;
import com.redBus.model.dto.UserHistory;
import com.redBus.repository.UserRepository;

@SpringBootTest
public class TestUserService {
    @Autowired
	private UserService userService;
    
    
    @Mock
    private UserRepository userRepository;

    
    
    
    @ParameterizedTest
    @ValueSource(strings = {"rkarande@galaxe.com"})
    public void testFindUserWithValidEmail(String email) {
    	Users users = userService.findUser(email);
    	String actualEmail= users.getEmail();
    	String expectedEmail="rkarande@galaxe.com";
    	Assertions.assertEquals(expectedEmail,actualEmail,"results are not matching");
    }
    
    @ParameterizedTest
    @ValueSource(strings = {"rka11rande@galaxe.com"})
    public void testFindUserWithInvalidEmail(String email) {
    	Assertions.assertThrows(UserNotFoundException.class,()->{
    		userService.findUser(email);
    	});
    }
    @Test
    public void testRegisterUserWithValidData() {
        UserDto userDto = new UserDto();
        userDto.setName("Narendra Modi");
        userDto.setUsername("Modi2024");
        userDto.setEmail("nmodi2024@example.com");
        userDto.setPassword("password123");
        userDto.setRole("USER");

        Users registeredUser = userService.registerUser(userDto);

        Assertions.assertNotNull(registeredUser);
        Assertions.assertEquals(userDto.getName(), registeredUser.getName());
        Assertions.assertEquals(userDto.getUsername(), registeredUser.getUsername());
        Assertions.assertEquals(userDto.getEmail(), registeredUser.getEmail());
        Assertions.assertEquals(userDto.getRole(), registeredUser.getRole());
    }

    @ParameterizedTest
    @ValueSource(strings = {"rkarande@galaxe.com"})
    public void testRegisterUserWithExistingEmail(String existingEmail) {
        UserDto userDto = new UserDto();
        userDto.setName("John Doe");
        userDto.setUsername("john.doe");
        userDto.setEmail(existingEmail); 
        userDto.setPassword("password123");
        userDto.setRole("USER");

        Assertions.assertThrows(UserAlreadyExistsException.class, () -> {
            userService.registerUser(userDto);
        });
    }

    @ParameterizedTest
    @ValueSource(strings = {"Rushi0620"})
    public void testRegisterUserWithExistingUsername(String existingUsername) {
        UserDto userDto = new UserDto();
        userDto.setName("John Doe");
        userDto.setUsername(existingUsername); 
        userDto.setEmail("newuser@example.com");
        userDto.setPassword("password123");
        userDto.setRole("USER");

        Assertions.assertThrows(UserAlreadyExistsException.class, () -> {
            userService.registerUser(userDto);
        });
    }
    
    
    @Test
    public void testGetAllUsers() {
        List<Users> allUsers = userService.getAllUsers();
        Assertions.assertNotNull(allUsers);
    }

    @Test
    public void testLoginWithValidCredentials() {
        UserDto userDto = new UserDto();
        userDto.setUsername("Rushi0620");
        userDto.setPassword("12345678");

        Users user = userService.login(userDto);

        Assertions.assertNotNull(user);
        
    }

    @Test
    public void testLoginWithInvalidCredentials() {
        UserDto userDto = new UserDto();
        userDto.setUsername("Rushi0620");
        userDto.setPassword("abcdefg");

        Assertions.assertThrows(InvalidCredentialsException.class, () -> {
            userService.login(userDto);
        });
    }

    @Test
    public void testUpdateUserWithValidEmail() {
        UserDto updatedUserDto = new UserDto();
        updatedUserDto.setEmail("newemail@example.com");
        updatedUserDto.setName("New Name");
        updatedUserDto.setUsername("newUsername");

        Users updatedUser = userService.updateUser("mujib@gmail.com", updatedUserDto);

        Assertions.assertNotNull(updatedUser);
        Assertions.assertEquals(updatedUserDto.getEmail(), updatedUser.getEmail());
        Assertions.assertEquals(updatedUserDto.getName(), updatedUser.getName());
        Assertions.assertEquals(updatedUserDto.getUsername(), updatedUser.getUsername());
    }

    @Test
    public void testUpdateUserWithInvalidEmail() {
        UserDto updatedUserDto = new UserDto();
        updatedUserDto.setEmail("newemail@example.com");
        updatedUserDto.setName("New Name");
        updatedUserDto.setUsername("newUsername");

        Assertions.assertThrows(UserNotFoundException.class, () -> {
            userService.updateUser("1234aaa@gmail.com", updatedUserDto);
        });
    }

    @Test
    public void testGetAllBookings() {
        // Arrange
        long validUserId = 1;
        Users mockUser = new Users();
        mockUser.setId(validUserId);

        Date date1 = new Date(); 
        List<Bookings> mockBookings = Arrays.asList(
                new Bookings(1L, mockUser, new BusScheduler(), date1, 2, new ArrayList<>(), new ArrayList<>(), 1000.0, "123xyz")
        );

        // Mock behavior
        Mockito.when(userRepository.findById(validUserId)).thenReturn(Optional.ofNullable(mockUser));
        Mockito.when(mockUser.getBookings()).thenReturn(mockBookings);

        // Act
        List<UserHistory> bookingHistory = userService.getAllBookings(validUserId);

        // Assert
        Assertions.assertNotNull(bookingHistory, "Booking history should not be null");
        Assertions.assertFalse(bookingHistory.isEmpty(), "Booking history should not be empty for a valid user ID");

        for (UserHistory userHistory : bookingHistory) {
            Assertions.assertNotNull(userHistory.getBookingId(), "Booking ID should not be null");
            Assertions.assertNotNull(userHistory.getBookingDate(), "Booking date should not be null");
            Assertions.assertNotNull(userHistory.getDateOfTravel(), "Date of travel should not be null");
            Assertions.assertNotNull(userHistory.getNoOfSeats(), "Number of seats should not be null");
            Assertions.assertNotNull(userHistory.getSource(), "Source should not be null");
            Assertions.assertNotNull(userHistory.getDestination(), "Destination should not be null");
        }

        // Verify that the repository method was called with the correct user ID
        Mockito.verify(userRepository).findById(validUserId);
    }
    @Test
    public void testGetAllBookingsForInvalidUserId() {
        Long invalidUserId = 9L;

        Assertions.assertThrows(UserNotFoundException.class, () -> {
            userService.getAllBookings(invalidUserId);
        }, "Should throw UserNotFoundException for an invalid user ID");
    }
    
}
