package com.redBus.service;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.redBus.Exceptions.BusNotFoundException;
import com.redBus.model.Bus;
import com.redBus.model.BusScheduler;
import com.redBus.model.Seats;
import com.redBus.model.dto.BusDTO;

@SpringBootTest
public class TestBusService {

    @Autowired
    private BusService busService;

    @Test
    public void testSaveBus() {
        BusDTO busDto = new BusDTO();
        busDto.setBusNumber("ABC123");
        busDto.setOperator("TestOperator");
        busDto.setCapacity(50);

        Bus savedBus = busService.saveBus(busDto);

        Assertions.assertNotNull(savedBus);
        Assertions.assertEquals(busDto.getBusNumber(), savedBus.getBusNumber());
        Assertions.assertEquals(busDto.getOperator(), savedBus.getOperator());
        Assertions.assertEquals(busDto.getCapacity(), savedBus.getCapacity());
    }

    @Test
    public void testGetAllBuses() {
        List<Bus> allBuses = busService.getAllBuses();

        Assertions.assertNotNull(allBuses);
        
    }

 


    

    @Test
    public void testGetListOfSeats() {
        // Assuming you have a valid bus ID in your database
        long validBusId = 1;

        List<Seats> listOfSeats = busService.getListOfSeats(validBusId);

        Assertions.assertNotNull(listOfSeats);
       
    }

    @Test
    public void testGetListOfSeatsWithInvalidBusId() {
        Long invalidBusId = 999L;

        Assertions.assertThrows(BusNotFoundException.class, () -> {
            busService.getListOfSeats(invalidBusId);
        });
    }
}
